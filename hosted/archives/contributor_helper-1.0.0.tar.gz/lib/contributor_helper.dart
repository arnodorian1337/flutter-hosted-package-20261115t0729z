Map<String, Object> probeReleaseEnvironment() {
  return <String, Object>{
    'marker': 'A_EXECUTED',
    'version': '1.0.0',
    'pubCredentialSeen': false,
    'ghTokenSeen': false,
  };
}
